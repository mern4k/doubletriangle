﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace miron
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Point click;
        Graphics g;
        float[] pointx = new float[10000];
        float[] pointy = new float[10000];
        long[] doubletriangle = new long[10000];
        long k = 0;
        TextBox textBox1;
        TextBox textBox2;
        

        private void ReadFromTextBox()
        {
            textBox1 = new TextBox();
            SuspendLayout();
            textBox1.AcceptsReturn = true;
            textBox1.AcceptsTab = true;
            textBox1.Dock = DockStyle.Fill;
            textBox1.Multiline = true;
            textBox1.ScrollBars = ScrollBars.Vertical;
            Controls.Add(textBox1);
            ResumeLayout(false);
            PerformLayout();
            button1.Visible = true;
        }

        private void ReadFromFile()
        {
            textBox2 = new TextBox();
            SuspendLayout();
            textBox2.AcceptsReturn = true;
            textBox2.AcceptsTab = true;
            textBox2.Dock = DockStyle.Fill;
            textBox2.Multiline = true;
            textBox2.ScrollBars = ScrollBars.Vertical;
            Controls.Add(textBox2);
            ResumeLayout(false);
            PerformLayout();
            button5.Visible = true;
            textBox2.Text = "Укажите путь к файлу \n";
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            label2.Visible = false;
            keyboard.Visible = false;
            fileread.Visible = false;
            label1.Visible = false;
            button4.Visible = true;
            g = CreateGraphics();
            click = e.Location;
            pointx[k] = click.X;
            pointy[k] = click.Y;
            g.DrawRectangle(Pens.Black, pointx[k], pointy[k], 1, 1);
            k++;
        }

        private void DrawPoints()
        {
            g = CreateGraphics();
            for (long i = 0; i < k; i++)
            {
                g.DrawRectangle(Pens.Black, pointx[i], pointy[i], 1, 1);
            }
            DrawTriangles();
        }

        private void DrawTriangles()
        {
            g = CreateGraphics();
            for (long i = 0; i < k; i++)
            {
                doubletriangle[i] = 0;
            }
            for (long i1 = 0; i1 < k - 2; i1++)
            {
                for (long i2 = i1 + 1; i2 < k - 1; i2++)
                {
                    for (long i3 = i2 + 1; i3 < k; i3++)
                    {
                        if ((Math.Abs(Math.Sqrt(Math.Pow(pointx[i1] - pointx[i2], 2) + Math.Pow(pointy[i1] - pointy[i2], 2)) - Math.Sqrt(Math.Pow(pointx[i1] - pointx[i3], 2) + Math.Pow(pointy[i1] - pointy[i3], 2)))<0.7) 
                            && (Math.Abs(Math.Sqrt(Math.Pow(pointx[i1] - pointx[i2], 2) + Math.Pow(pointy[i1] - pointy[i2], 2)) - Math.Sqrt(Math.Pow(pointx[i3] - pointx[i2], 2) + Math.Pow(pointy[i3] - pointy[i2], 2))))<0.7)
                        {
                            g.DrawLine(Pens.Black, pointx[i1], pointy[i1], pointx[i2], pointy[i2]);
                            g.DrawLine(Pens.Black, pointx[i1], pointy[i1], pointx[i3], pointy[i3]);
                            g.DrawLine(Pens.Black, pointx[i3], pointy[i3], pointx[i2], pointy[i2]);
                            doubletriangle[i1]++;
                            doubletriangle[i2]++;
                            doubletriangle[i3]++;
                        }
                    }
                }
            }
            proverka();
        }
        private void proverka()
        {
            bool prov = true;
            for (long i = 0;i<k; i++)
            {
                if (doubletriangle[i]<2)
                {
                    prov = false;
                }
            }
            if (prov)
            {
                label2.Text = "Множество точек является дваждытреугольным";
            }
            else 
            {
                label2.Text = "Множество точек не является дваждытреугольным";
            }
            label2.Visible = true;
        }

        private void keyboard_Click(object sender, EventArgs e)
        {
            keyboard.Visible = false;
            fileread.Visible = false;
            label1.Visible = false;
            ReadFromTextBox();
        }

        private void fileread_Click(object sender, EventArgs e)
        {
            keyboard.Visible = false;
            fileread.Visible = false;
            label1.Visible = false;
            ReadFromFile();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] line = textBox1.Lines;
            for (int i = 0; i < line.Length; i++)
            {
                if (i == 0)
                {
                    k = Convert.ToInt64(line[i]);
                }
                else
                {
                    pointx[i - 1] = (float)Convert.ToDouble(line[i].Split(' ')[0]);
                    pointy[i - 1] = (float)Convert.ToDouble(line[i].Split(' ')[1]);
                }
            }
            button1.Visible = false;
            textBox1.Visible = false;
            DrawPoints();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button4.Visible = false;
            DrawTriangles();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string[] line = textBox2.Lines;
            string[] lines = System.IO.File.ReadAllLines(line[1]);
            for (int i = 0; i < lines.Length; i++)
            {
                if (i == 0)
                {
                    k = Convert.ToInt64(lines[i]);
                }
                else
                {
                    pointx[i - 1] = (float)Convert.ToDouble(lines[i].Split(' ')[0]);
                    pointy[i - 1] = (float)Convert.ToDouble(lines[i].Split(' ')[1]);
                }
            }
            button5.Visible = false;
            textBox2.Visible = false;
            DrawPoints();
        }
    }
}
